export interface ThemeProps {
    darkMode: boolean;
    toggleDarkMode: () => void;
  }